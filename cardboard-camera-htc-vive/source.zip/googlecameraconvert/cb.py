import subprocess, os, json, itertools, sys
from base64 import b64decode
from cStringIO import StringIO
from PIL import Image, ImageFilter, ImageDraw


def decode_base64(data):
    missing_padding = len(data) % 4
    if missing_padding != 0:
        data += b'='* (4 - missing_padding)
    return b64decode(data)

def exiftool(cmd):
    process = subprocess.Popen("exiftool "+cmd, stdout=subprocess.PIPE, shell=True)
    process_data = process.stdout.read()
    process.kill()
    return process_data.strip()

output_dir = sys.argv[1] + "output"

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

jpg_list = sys.argv[2:]

for idx, oi in enumerate(jpg_list):

    print "====== Start Processing {0} ({1}/{2}) ======".format(oi, idx+1, len(jpg_list))

    
    #Get Image Information
    print "Fetch Image Information ... "
    meta = json.loads(exiftool("-G -j -sort {0}".format(oi)).decode("utf-8").rstrip("\r\n"))[0]
    i_w = int(meta[u"XMP:FullPanoWidthPixels"])
    i_h = int(i_w/2)
    c_h = int(meta[u"XMP:CroppedAreaImageHeightPixels"])
    c_t = int(meta[u"XMP:CroppedAreaTopPixels"])
    c_b = i_h-c_h-c_t

    
    #Extract Right Eye Image
    print "Extract Right Eye Image ... "
    r_data = exiftool("{0} -XMP-GImage:Data -b".format(oi))
    ri = StringIO(decode_base64(r_data))


    #Image Setting
    lm = Image.open(oi)
    rm = Image.open(ri)
    main = Image.new("RGB", (i_w, i_h*2))

    im_list = []


    #Create Alpha Mask for Image Overlay    
    mask = Image.new("L", (i_w, i_h))
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.rectangle([0, 0, i_w, c_t], 255)
    mask_draw.rectangle([0, c_t+c_h, i_w, i_h], 255)
    del mask_draw
    mask = mask.filter(ImageFilter.GaussianBlur(50))


    #Image Process    
    for pic, eye in itertools.izip([lm, rm], ["Left", "Right"]):
        print "Post-Processing {0} Eye Image ... ".format(eye)
        pic_t = pic.copy().crop((0, 0, i_w, int(c_t/float(c_t+c_b)*c_h))).transpose(Image.FLIP_TOP_BOTTOM).resize((i_w, c_t))
        pic_d = pic.copy().crop((0, int(c_t/float(c_t+c_b)*c_h), i_w, c_h)).transpose(Image.FLIP_TOP_BOTTOM).resize((i_w, c_b))
        pic_canvas = Image.new("RGB", (i_w, i_h))
        pic_canvas.paste(pic_t, (0, 0))
        pic_canvas.paste(pic, (0, c_t))
        pic_canvas.paste(pic_d, (0, c_t+c_h))  
        pic_overlay = pic_canvas.copy().filter(ImageFilter.GaussianBlur(100))
        pic_canvas.paste(pic_overlay, (0, 0), mask)
        im_list.append(pic_canvas)
        for im in [pic, pic_t, pic_d, pic_overlay]:
            im.close()
        

    #Composite and Output
    print "Finalize Composition ... "
    main.paste(im_list[0], (0, 0))
    main.paste(im_list[1], (0, i_h))
    main.save(output_dir + "/" + os.path.basename(oi))

    for im in ([mask, main, lm, rm] + im_list):
        im.close()
    ri.truncate(0)
    

print "Finsh!!"
